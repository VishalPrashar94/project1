
package project1;

import java.util.Scanner;

/**
 *
 * @author Prashar Saab
 */
public class Project1 {

    
      
   
    public static void main(String[] args) {
       String[] nameList = new String[10];
       String toContinue = "Y";
       int choice;
       while(toContinue.equals("Y")){
        choice = menuPrint();
        if (choice == 1) {
            
            optionDisplay(nameList);
           
        }
        else if(choice == 2){
            optionInsert(nameList);
  
        }
        else if(choice == 3){
            optionSwap(nameList);
        }
        else if (choice == 4){
            System.out.println("END OF PROJECT");
            break;
        
        }
       }
    }
    
    
    public static int menuPrint(){
        System.out.println("----------------------------------------------------------MAIN MENU---------------------------------------------------------------");
        System.out.println("STUDENT ID : 1794421");
        System.out.println("STUDENT NAME : Vishal Prashar");
        System.out.println("");
        System.out.println("1. Display the list \n" +  "2. Insert an element \n" + "3. Swap the elements \n" +  "4. Quit \n");
        
        System.out.print("Your choice ? : ");
        Scanner input = new Scanner(System.in);
        int c = input.nextInt();
        System.out.println("");
        return c;
        
    }
    
    
    public static void vectorPrint(String[] vector){
        System.out.println("LIST CONTENT : ");
        for (int i = 0; i < 10; i++) {
            System.out.println((i+1) + ". " + vector[i]);
            
        }
    }
    
    public static void optionDisplay(String[] vector){
        vectorPrint(vector);
        System.out.println("");
        System.out.print("press Enter to continue : ");
        Scanner s = new Scanner(System.in);
        String blank = s.nextLine();
        
    }

    public static void optionInsert(String[] vector) {
        System.out.println("INSERT AN ELEMENT");
        vectorPrint(vector);
        System.out.println("");
        Scanner keyboard = new Scanner(System.in);
        String nameToInsert = new String();

        int i;
        int index;
        System.out.print("Where do you want to insert ? : ");
        index = keyboard.nextInt();
        keyboard.nextLine();
        System.out.print("Please enter name: ");
        nameToInsert = keyboard.nextLine();

        for (i = 0; i < 10; i++) {
            if(i == index){
                vector[index - 1] = nameToInsert;
            }
        }
       
  

    }
    
   
    public static void optionSwap(String[] vector){
        System.out.println("SWAP TWO ELEMENTS");
        vectorPrint(vector);
        System.out.println("");
        Scanner keyboard = new Scanner(System.in);
        int fromIndex, toIndex;
        System.out.print("From element : ");
        fromIndex = keyboard.nextInt();
        keyboard.nextLine();
        System.out.print("To element : ");
        toIndex = keyboard.nextInt();

        String switchIt ;
        switchIt = vector[fromIndex-1];
        vector[fromIndex-1] = vector[toIndex-1];
        vector[toIndex-1] = switchIt;
        
    }
    
    
    
    
    }
    

